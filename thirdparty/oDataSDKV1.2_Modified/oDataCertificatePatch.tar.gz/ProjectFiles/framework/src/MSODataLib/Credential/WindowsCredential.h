/*
 Copyright 2010 Microsoft Corp
 
 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at
 
 http://www.apache.org/licenses/LICENSE-2.0
 
 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 */

#import <Foundation/Foundation.h>
#import "CredentialBase.h"

@interface WindowsCredential : CredentialBase {
	
	@private
	
	/**
	 * HTTP request user name
	 */
	NSString *m_userName;
	
	/**
	 * HTTP request password
	 */
    NSString *m_password;

   /**
    * Flag to trust server even if certificate is not valid or 
    * self-signed 
    */
   BOOL m_trustServer;
}

@property (nonatomic, retain , getter=getUserName, setter=setUserName )NSString *m_userName;
@property (nonatomic, retain , getter=getPassword, setter=setPassword )NSString *m_password;
@property (nonatomic, getter=getTrust, setter=setTrust )BOOL m_trustServer;

- (id) initWithUserName:(NSString *)anUserName password:(NSString *)aPassword;
- (id) initWithUserName:(NSString *)anUserName password:(NSString *)aPassword trustServer:(BOOL)aTrust;
- (void) setProxy:(HttpProxy*)aProxy;
- (NSDictionary*) getSignedHeaders:(NSString*)aRequestUrl;
- (NSString *) getCredentialType;
- (BOOL) getTrustServer;
@end
